<x-filament-panels::page>
    <form wire:submit.prevent="update">
    {{ $this->form }}
    </form>
</x-filament-panels::page>
