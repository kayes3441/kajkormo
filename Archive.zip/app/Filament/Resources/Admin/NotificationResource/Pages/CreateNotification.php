<?php

namespace App\Filament\Resources\Admin\NotificationResource\Pages;

use App\Filament\Resources\Admin\NotificationResource\NotificationResource;
use Filament\Resources\Pages\CreateRecord;

class CreateNotification extends CreateRecord
{
    protected static string $resource = NotificationResource::class;
}
